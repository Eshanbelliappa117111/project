(function(d){var h=[];d.loadImages=function(a,e){"string"==typeof a&&(a=[a]);for(var f=a.length,g=0,b=0;b<f;b++){var c=document.createElement("img");c.onload=function(){g++;g==f&&d.isFunction(e)&&e()};c.src=a[b];h.push(c)}}})(window.jQuery);
$.fn.hasAttr = function(name) { var attr = $(this).attr(name); return typeof attr !== typeof undefined && attr !== false; };

var lwi=-1;function thresholdPassed(){var w=$(window).width();var p=false;var cw=0;if(w>=960){cw++;}if(lwi!=cw){p=true;}lwi=cw;return p;}
function em1(){var c="bdbefnzAhnbjm/dpn";var addr="mailto:";for(var i=0;i<c.length;i++)addr+=String.fromCharCode(c.charCodeAt(i)-1);window.location.href=addr;}

$(document).ready(function() {
r=function(){if(thresholdPassed()){dpi=window.devicePixelRatio;if($(window).width()>=960){$('.js5').attr('src', 'images/feat-card-2-447.jpg');
$('.js6').attr('src', 'images/research-1-264.png');
$('.js7').attr('src', 'images/research-2-273.png');
$('.js8').attr('src', 'images/10_feb-151.png');
$('.js9').attr('src', 'images/15_july-151.png');
$('.js10').attr('src', 'images/18_jun-151.png');
$('.js11').attr('src', 'images/22_march-151.png');
$('.js12').attr('src', 'images/responsive_web_des-447-2.png');
$('.js13').attr('src', 'images/leadership_quality-447-1.jpg');
$('.js14').attr('src', 'images/logo-200.png');
$('.js15').attr('src', (dpi>1) ? ((dpi>2) ? 'images/facebook-90.jpg' : 'images/facebook-60.jpg') : 'images/facebook-30.jpg');
$('.js16').attr('src', (dpi>1) ? ((dpi>2) ? 'images/instagram-87.jpg' : 'images/instagram-58.jpg') : 'images/instagram-29.jpg');
$('.js17').attr('src', (dpi>1) ? ((dpi>2) ? 'images/images-87.png' : 'images/images-58.png') : 'images/images-29.png');
$('.js18').attr('src', (dpi>1) ? ((dpi>2) ? 'images/location-63.png' : 'images/location-42.png') : 'images/location-21.png');
$('.js').attr('src', 'images/logo-copy-200.png');
$('.js2').attr('src', (dpi>1) ? ((dpi>2) ? 'images/location-81.jpg' : 'images/location-54.jpg') : 'images/location-27.jpg');
var a='data-src'; if($('.js3 .slide0').hasAttr('src')) { a='src'; } $('.js3 .slide0').attr(a, 'images/slider-1-1440-1.png');
var a='data-src'; if($('.js3 .slide1').hasAttr('src')) { a='src'; } $('.js3 .slide1').attr(a, 'images/slider-1-1440-1.png');
var a='data-src'; if($('.js3 .slide2').hasAttr('src')) { a='src'; } $('.js3 .slide2').attr(a, 'images/slider-1-1440-1.png');
$('.js4').attr('src', 'images/feat-card-1-447.jpg');}else{$('.js5').attr('src', (dpi>1) ? 'images/feat-card-2-574.jpg' : 'images/feat-card-2-287.jpg');
$('.js6').attr('src', (dpi>1) ? 'images/research-1-256.png' : 'images/research-1-128-1.png');
$('.js7').attr('src', (dpi>1) ? 'images/research-2-264.png' : 'images/research-2-132-1.png');
$('.js8').attr('src', (dpi>1) ? 'images/10_feb-182.png' : 'images/10_feb-91-1.png');
$('.js9').attr('src', (dpi>1) ? 'images/15_july-182.png' : 'images/15_july-91-1.png');
$('.js10').attr('src', (dpi>1) ? 'images/18_jun-182.png' : 'images/18_jun-91-1.png');
$('.js11').attr('src', (dpi>1) ? 'images/22_march-182.png' : 'images/22_march-91-1.png');
$('.js12').attr('src', (dpi>1) ? 'images/responsive_web_des-574-1.png' : 'images/responsive_web_des-287-2.png');
$('.js13').attr('src', (dpi>1) ? 'images/leadership_quality-574-1.jpg' : 'images/leadership_quality-287-1.jpg');
$('.js14').attr('src', (dpi>1) ? 'images/logo-196.png' : 'images/logo-98.png');
$('.js15').attr('src', (dpi>1) ? ((dpi>2) ? 'images/facebook-51.jpg' : 'images/facebook-34.jpg') : 'images/facebook-17.jpg');
$('.js16').attr('src', (dpi>1) ? ((dpi>2) ? 'images/instagram-51.jpg' : 'images/instagram-34.jpg') : 'images/instagram-17.jpg');
$('.js17').attr('src', (dpi>1) ? ((dpi>2) ? 'images/images-51.png' : 'images/images-34.png') : 'images/images-17.png');
$('.js18').attr('src', (dpi>1) ? ((dpi>2) ? 'images/location-45.png' : 'images/location-30.png') : 'images/location-15.png');
$('.js').attr('src', 'images/logo-copy-139.png');
$('.js2').attr('src', (dpi>1) ? ((dpi>2) ? 'images/location-51.jpg' : 'images/location-34.jpg') : 'images/location-17.jpg');
var a='data-src'; if($('.js3 .slide0').hasAttr('src')) { a='src'; } $('.js3 .slide0').attr(a, (dpi>1) ? 'images/slider-1-960-1.png' : 'images/slider-1-480-1.png');
var a='data-src'; if($('.js3 .slide1').hasAttr('src')) { a='src'; } $('.js3 .slide1').attr(a, (dpi>1) ? 'images/slider-1-960-1.png' : 'images/slider-1-480-1.png');
var a='data-src'; if($('.js3 .slide2').hasAttr('src')) { a='src'; } $('.js3 .slide2').attr(a, (dpi>1) ? 'images/slider-1-960-1.png' : 'images/slider-1-480-1.png');
$('.js4').attr('src', (dpi>1) ? 'images/feat-card-1-574.jpg' : 'images/feat-card-1-287.jpg');}}};
if(!window.HTMLPictureElement){$(window).resize(r);r();}
(function(){$('a[href^="#"]:not(.allowConsent,.noConsent,.denyConsent,.removeConsent)').each(function(){$(this).click(function(){var t=this.hash.length>1?$('[name="'+this.hash.slice(1)+'"]').offset().top:0;return $("html, body").animate({scrollTop:t},400),!1})})})();
initMenu($('#m1')[0]);
initMenu($('#m2')[0]);
$('.c78').Stickyfill();
$('.js3 .slider').slick({lazyLoad: 'ondemand',slidesToShow: 1,slidesToScroll: 1,fade: true,slide: 'div',cssEase: 'linear',speed: 300,dots: true,arrows: false,infinite: true,autoplay: true,pauseOnHover: false,autoplaySpeed: 2500});
});